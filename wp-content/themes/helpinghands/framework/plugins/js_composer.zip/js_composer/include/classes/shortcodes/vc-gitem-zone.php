<?php

Class WPBakeryShortCode_VC_Gitem_Zone extends WPBakeryShortCodesContainer {
	public $zone_name = '';
}